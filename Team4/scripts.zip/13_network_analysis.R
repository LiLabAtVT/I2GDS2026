#!/usr/bin/env Rscript
# Reproduces Fig. 7/8 (co-occurrence networks) and Table 1 (topology metrics)
# from the fastspar (SparCC) correlation + pseudo-p-value matrices.
suppressPackageStartupMessages({
  library(igraph); library(ggraph); library(ggplot2)
})
set.seed(42)

BASE <- "/projects/intro2gds/I2GDS2026/Team4/vinny/Claude_Code"
setwd(BASE)
dir.create("pdf_output", showWarnings = FALSE)
dir.create("results/stats", showWarnings = FALSE, recursive = TRUE)

read_sq <- function(path) {
  m <- read.delim(path, row.names = 1, check.names = FALSE)
  as.matrix(m)
}

build_network <- function(subdir, label, min_cor = 0.2, max_p = 0.05) {
  cor_m <- read_sq(file.path(subdir, "median_correlation.tsv"))
  p_m <- read_sq(file.path(subdir, "pvalues.tsv"))
  genus_map <- read.csv(file.path(subdir, "asv_genus_map.csv"), row.names = 1)

  diag(cor_m) <- 0
  keep <- (abs(cor_m) >= min_cor) & (p_m < max_p)
  keep[is.na(keep)] <- FALSE
  adj <- cor_m
  adj[!keep] <- 0

  g <- graph_from_adjacency_matrix(adj, mode = "undirected", weighted = "correlation", diag = FALSE)
  g <- delete_vertices(g, which(degree(g) == 0))
  V(g)$genus <- genus_map[V(g)$name, "genus"]
  E(g)$sign <- ifelse(E(g)$correlation > 0, "positive", "negative")

  cat(sprintf("[%s] network: %d nodes, %d edges\n", label, vcount(g), ecount(g)))

  ## ---- Table 1 style topology metrics ----
  deg <- degree(g)
  betw <- betweenness(g, weights = abs(E(g)$correlation))
  clos <- closeness(g, weights = abs(E(g)$correlation))
  eig <- tryCatch(eigen_centrality(g, weights = abs(E(g)$correlation))$vector, error = function(e) rep(NA, vcount(g)))
  topo <- data.frame(
    network = label,
    avg_degree = mean(deg),
    avg_clustering_coeff = transitivity(g, type = "global"),
    density = edge_density(g),
    max_degree = max(deg),
    node_max_degree = paste(V(g)$genus[which.max(deg)], collapse = ","),
    max_betweenness = max(betw),
    node_max_betweenness = paste(V(g)$genus[which.max(betw)], collapse = ","),
    max_eigenvector = max(eig, na.rm = TRUE),
    node_max_eigenvector = paste(V(g)$genus[which.max(eig)], collapse = ","),
    max_closeness = max(clos),
    node_max_closeness = paste(V(g)$genus[which.max(clos)], collapse = ","),
    transitivity = transitivity(g, type = "global"),
    n_nodes = vcount(g), n_edges = ecount(g)
  )
  list(graph = g, topo = topo)
}

canker <- build_network("results/sparcc/canker", "Canker (threshold-style r>=0.2,p<0.05)")
healthy <- build_network("results/sparcc/healthy", "Healthy (threshold-style r>=0.2,p<0.05)")

topo_all <- rbind(canker$topo, healthy$topo)
write.csv(topo_all, "results/stats/Table1_network_topology.csv", row.names = FALSE)
print(topo_all)

plot_network <- function(res, title, file) {
  g <- res$graph
  pdf(file, width = 10, height = 10)
  p <- ggraph(g, layout = "fr") +
    geom_edge_link(aes(color = sign, width = abs(correlation)), alpha = 0.6) +
    scale_edge_color_manual(values = c(positive = "steelblue", negative = "firebrick")) +
    geom_node_point(size = 4, color = "grey20") +
    geom_node_text(aes(label = genus), repel = TRUE, size = 2.5) +
    theme_void() + labs(title = title)
  print(p)
  dev.off()
}

plot_network(canker, "Canker microbiome co-occurrence network (SparCC/fastspar)", "pdf_output/Fig7_canker_network.pdf")
plot_network(healthy, "Healthy microbiome co-occurrence network (SparCC/fastspar)", "pdf_output/Fig8_healthy_network.pdf")

## ---- Erwinia-centric positive/negative interaction summary (Fig 7B/D style) ----
summarize_erwinia <- function(res, label) {
  g <- res$graph
  erw_idx <- grep("Erwinia", V(g)$genus, ignore.case = TRUE)
  if (length(erw_idx) == 0) return(NULL)
  erw_names <- V(g)$name[erw_idx]
  el <- as_data_frame(g, what = "edges")
  el_sub <- el[el$from %in% erw_names | el$to %in% erw_names, ]
  el_sub$network <- label
  el_sub
}
erw_canker <- summarize_erwinia(canker, "canker")
erw_healthy <- summarize_erwinia(healthy, "healthy")
write.csv(rbind(erw_canker, erw_healthy), "results/stats/Erwinia_interactions.csv", row.names = FALSE)

cat("DONE: network_analysis\n")
