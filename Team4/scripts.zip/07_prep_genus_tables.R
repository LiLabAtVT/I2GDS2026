#!/usr/bin/env Rscript
# Shared preprocessing: builds genus-level count + relative-abundance tables
# used by LEfSe, Dirichlet-multinomial driver annotation, and FAPROTAX scripts.
BASE <- "/projects/intro2gds/I2GDS2026/Team4/vinny/Claude_Code"
setwd(BASE)
dir.create("results/stats", showWarnings = FALSE, recursive = TRUE)

ft <- read.delim("results/exports/table/feature-table.tsv", skip = 1, row.names = 1, check.names = FALSE)
tax <- read.delim("results/exports/taxonomy/taxonomy.tsv", check.names = FALSE)

get_genus <- function(tx) {
  parts <- strsplit(tx, ";")[[1]]
  g <- grep("^g__", parts, value = TRUE)
  if (length(g) == 0 || g == "g__") return("Unclassified")
  sub("^g__", "", g)
}
tax$genus <- sapply(tax$Taxon, get_genus)
genus_map <- setNames(tax$genus, tax$`Feature ID`)

ft2 <- ft
ft2$genus <- genus_map[rownames(ft2)]
ft2$genus[is.na(ft2$genus)] <- "Unclassified"
genus_counts <- aggregate(. ~ genus, data = ft2, FUN = sum)
rownames(genus_counts) <- genus_counts$genus
genus_counts$genus <- NULL
genus_counts <- as.matrix(genus_counts)
genus_rel <- sweep(genus_counts, 2, colSums(genus_counts), "/") * 100

write.csv(genus_counts, "results/stats/genus_counts.csv")
write.csv(genus_rel, "results/stats/genus_relative_abundance.csv")
cat("DONE: genus tables written,", nrow(genus_counts), "genera x", ncol(genus_counts), "samples\n")
