#!/bin/bash
# Download all PRJNA1348523 HiFi FASTQs from ENA and verify MD5s.
BASE=$(cd "$(dirname "$0")/.." && pwd); cd "$BASE/raw_data"
tail -n +2 "$BASE/metadata/ena_runinfo.tsv" | while IFS=$'\t' read run s alias t e l i rc bc ftp bytes md5; do
  f=$run.fastq.gz
  if [ ! -s "$f" ] || [ "$(md5sum "$f" | cut -d' ' -f1)" != "$md5" ]; then
    wget -q -c -O "$f" "https://$ftp" || echo "FAIL $run"
  fi
  [ "$(md5sum "$f" | cut -d' ' -f1)" = "$md5" ] && echo "OK $run" || echo "MD5_MISMATCH $run"
done | tee "$BASE/logs/download_md5.log"
