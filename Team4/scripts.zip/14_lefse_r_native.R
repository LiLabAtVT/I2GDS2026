#!/usr/bin/env Rscript
# Reproduces Fig. 5A: LEfSe (Segata et al. 2011) canker-vs-healthy differential
# genera. Implements LEfSe's core statistical method natively in R (Kruskal-Wallis
# screening + LDA effect-size ranking) rather than via the bioconda `lefse` Python
# package: that package's bootstrap-LDA step (rpy2-bridged to R) proved unreliable
# in this environment - robjects.r() intermittently returned None for assignment
# expressions regardless of the data, a pervasive rpy2/Python-R interop issue, not
# a statistical problem with this dataset (confirmed by direct replication). This
# script implements the same published algorithm directly, avoiding that bridge.
suppressPackageStartupMessages({
  library(MASS); library(ggplot2); library(dplyr)
})
set.seed(1982)

BASE <- "/projects/intro2gds/I2GDS2026/Team4/vinny/Claude_Code"
setwd(BASE)
dir.create("results/lefse", showWarnings = FALSE, recursive = TRUE)
dir.create("pdf_output", showWarnings = FALSE)

genus_rel <- read.csv("results/stats/genus_relative_abundance.csv", row.names = 1, check.names = FALSE)
## LEfSe's own CLI normalizes to a sum of 1,000,000 per sample (-o 1000000)
## before the LDA step; our table is on a 0-100% scale, so rescale to match
## the convention LEfSe scores (and the paper's Fig 5A) are reported on.
genus_rel <- genus_rel * (1e6 / 100)
meta <- read.delim("metadata/sample-metadata.tsv", check.names = FALSE)
meta <- meta[meta$`sample-id` != "#q2:types", ]
rownames(meta) <- meta$`sample-id`
meta <- meta[colnames(genus_rel), ]
class_lab <- factor(meta$health_status, levels = c("Healthy", "Canker"))

## ---- Step 1: Kruskal-Wallis screening (LEfSe default alpha = 0.05) ----
alpha_kw <- 0.05
kw_p <- apply(genus_rel, 1, function(x) {
  if (length(unique(x)) < 2) return(NA)
  tryCatch(kruskal.test(x, class_lab)$p.value, error = function(e) NA)
})
sig_genera <- rownames(genus_rel)[!is.na(kw_p) & kw_p < alpha_kw]
cat("Kruskal-Wallis significant genera:", length(sig_genera), "of", nrow(genus_rel), "\n")

## ---- Step 2: bootstrap-averaged LDA effect size on the significant subset ----
## LEfSe fits one joint multivariate LDA across all significant features at
## once, which is rank-deficient here (41 features, 40 samples) - a single
## full-data fit gives a numerically arbitrary (near-zero) effect size. LEfSe's
## own design handles this by averaging over many random subsamples rather than
## trusting one ill-conditioned fit; that bootstrap loop is reimplemented here
## in pure R (no Python/rpy2 bridge - that bridge was the unreliable part, not
## the statistical method itself).
safe_names <- make.names(sig_genera, unique = TRUE)
name_map <- setNames(sig_genera, safe_names)

df_full <- as.data.frame(t(genus_rel[sig_genera, , drop = FALSE]))
colnames(df_full) <- safe_names
df_full$class <- class_lab
n <- nrow(df_full)

n_boots <- 30
fract_sample <- 0.6667
rfk <- round(n * fract_sample)
boot_scores <- matrix(NA_real_, nrow = n_boots, ncol = length(safe_names),
                       dimnames = list(NULL, safe_names))

for (b in seq_len(n_boots)) {
  fit_ok <- FALSE
  for (attempt in seq_len(50)) {
    idx <- sample(seq_len(n), rfk, replace = TRUE)
    sub <- df_full[idx, ]
    if (length(unique(sub$class)) < 2) next
    ## jitter any genus that is exactly constant within a class in this subsample
    for (g in safe_names) {
      for (cl in levels(class_lab)) {
        gi <- which(sub$class == cl)
        if (length(gi) > 0 && length(unique(sub[gi, g])) == 1) {
          sub[gi, g] <- abs(sub[gi, g] + rnorm(length(gi), 0, max(sub[gi, g][1] * 0.05, 0.01)))
        }
      }
    }
    fit <- tryCatch(lda(class ~ ., data = sub, tol = 1e-10), error = function(e) NULL)
    if (is.null(fit)) next
    w <- fit$scaling[, 1]
    denom <- sqrt(sum(w^2))
    if (!is.finite(denom) || denom == 0) next
    w_unit <- w / denom
    LD <- as.matrix(sub[, safe_names]) %*% w_unit
    effect_size <- abs(mean(LD[sub$class == "Healthy"]) - mean(LD[sub$class == "Canker"]))
    means_mat <- fit$means
    if (!all(c("Healthy", "Canker") %in% rownames(means_mat))) next
    coeff <- abs(w_unit * effect_size)
    diff_means <- abs(means_mat["Healthy", ] - means_mat["Canker", ])
    boot_scores[b, ] <- (diff_means + coeff) / 2
    fit_ok <- TRUE
    break
  }
  if (!fit_ok) boot_scores[b, ] <- NA_real_
}

mean_raw_score <- colMeans(boot_scores, na.rm = TRUE)
n_valid_boots <- colSums(!is.na(boot_scores))
cat("Bootstrap fits succeeded for a median of", median(n_valid_boots), "/", n_boots, "iterations per genus\n")

## sign from full-data class means (direction is stable even when magnitude isn't)
full_means <- sapply(safe_names, function(g) {
  mean(df_full[df_full$class == "Canker", g]) - mean(df_full[df_full$class == "Healthy", g])
})
lda_log_score <- sign(full_means) * log10(1 + abs(mean_raw_score))
names(lda_log_score) <- safe_names
cat("mean_raw_score summary:\n"); print(summary(mean_raw_score))
cat("lda_log_score summary:\n"); print(summary(lda_log_score))
cat("top 5 |lda_log_score|:\n"); print(sort(abs(lda_log_score), decreasing = TRUE)[1:5])

## ---- Step 3: assemble results table (mirrors LEfSe's .res format) ----
res <- data.frame(
  genus = name_map[safe_names],
  log_max_mean = log10(1 + apply(genus_rel[sig_genera, , drop = FALSE], 1, max)),
  enriched_in = ifelse(lda_log_score > 0, "Canker", "Healthy"),
  lda_score = as.numeric(lda_log_score),
  p_value = kw_p[sig_genera],
  stringsAsFactors = FALSE
)
res <- res[order(-abs(res$lda_score)), ]
write.csv(res, "results/lefse/lefse_results_native.csv", row.names = FALSE)

## ---- Step 4: plot (Fig 5A style) - genera with |LDA score| > 2 (LEfSe default) ----
plot_df <- res[abs(res$lda_score) > 2, ]
plot_df$genus <- factor(plot_df$genus, levels = plot_df$genus[order(plot_df$lda_score)])

pdf("pdf_output/Fig5A_LEfSe_canker_vs_healthy.pdf", width = 9, height = max(6, nrow(plot_df) * 0.25))
p <- ggplot(plot_df, aes(x = genus, y = lda_score, fill = enriched_in)) +
  geom_col() + coord_flip() + theme_bw() +
  scale_fill_manual(values = c(Canker = "#D55E00", Healthy = "#009E73")) +
  labs(x = NULL, y = "LDA score (log10)", fill = "Enriched in",
       title = "LEfSe: canker vs. healthy differential genera")
print(p)
dev.off()

cat("DONE: lefse_r_native,", nrow(plot_df), "genera above |LDA|>2 threshold\n")
