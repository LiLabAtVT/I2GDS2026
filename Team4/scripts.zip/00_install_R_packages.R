# One-time environment setup for ARC (Tinkercliffs).
#
# Load with: module load R/4.4.2-gfbf-2024a R-bundle-Bioconductor/3.20-foss-2024a-R-4.4.2
# That bundle already provides vegan, randomForest, DirichletMultinomial, igraph,
# ggraph, ggplot2, reshape2, dplyr, magrittr, agricolae, ape, pheatmap, MASS -
# everything this pipeline needs except microeco (installed below).
#
# NOTE: an earlier attempt used R 4.3.2 (the cluster default) and additionally
# tried to install SpiecEasi (for a SparCC-like co-occurrence method), which
# requires R >= 4.5.0 and failed. The fix was twofold: (1) switch to the
# R 4.4.2 + Bioconductor 3.20 module pair above, which already has everything
# but microeco, and (2) drop SpiecEasi entirely in favor of `fastspar` (the
# modern SparCC reimplementation) and `lefse`, both installed via a separate
# conda env (see 12_sparcc_fastspar.sh / 08_lefse_prep_and_run.sh) rather than
# as R packages - this avoids the R-version conflict altogether.
lib <- .libPaths()[1]; dir.create(lib, recursive = TRUE, showWarnings = FALSE)
options(repos = c(CRAN = "https://cloud.r-project.org"), Ncpus = 8)
if (!requireNamespace("microeco", quietly = TRUE)) install.packages("microeco", lib = lib)
print(requireNamespace("microeco", quietly = TRUE))

# Conda env for fastspar + lefse (run once):
#   module load Miniconda3
#   conda create -y -n microbiome_tools -c bioconda -c conda-forge --override-channels fastspar lefse
