#!/usr/bin/env Rscript
# Reproduces Fig. 2 (alpha diversity) and Fig. 3 (beta diversity / PCoA / PERMANOVA)
# from BakhshiGanje et al. 2026, Phytobiomes 10:277-292.
suppressPackageStartupMessages({
  library(vegan); library(ggplot2); library(reshape2); library(dplyr)
  library(agricolae); library(ape)
})
set.seed(42)

BASE <- "/projects/intro2gds/I2GDS2026/Team4/vinny/Claude_Code"
setwd(BASE)
dir.create("results/stats", showWarnings = FALSE, recursive = TRUE)
dir.create("pdf_output", showWarnings = FALSE)

## ---- Load data ----
ft <- read.delim("results/exports/table/feature-table.tsv", skip = 1, row.names = 1, check.names = FALSE)
meta <- read.delim("metadata/sample-metadata.tsv", check.names = FALSE)
meta <- meta[meta$`sample-id` != "#q2:types", ]
rownames(meta) <- meta$`sample-id`
meta <- meta[colnames(ft), ]
meta$cultivar <- factor(meta$cultivar, levels = c("Aztec Fuji","Cripps Pink","Gala","Granniwinkle","Hewe's Crab","Unknown cultivar"))
meta$health_status <- factor(meta$health_status, levels = c("Healthy","Canker"))

otu <- t(as.matrix(ft))  # samples x ASVs, counts
storage.mode(otu) <- "numeric"

## ---- Rarefaction to even depth (paper: "ASV abundances were rarefied to the same sequencing depth") ----
depth <- min(rowSums(otu))
cat("Rarefying to depth:", depth, "\n")
otu_rare <- rrarefy(otu, sample = depth)

## ---- Alpha diversity: Chao1, Observed, Shannon, Simpson ----
chao1 <- apply(otu_rare, 1, function(x) estimateR(x)["S.chao1"])
observed <- specnumber(otu_rare)
shannon <- diversity(otu_rare, index = "shannon")
simpson <- diversity(otu_rare, index = "simpson")

alpha <- data.frame(sample = rownames(otu_rare), cultivar = meta$cultivar,
                     health_status = meta$health_status,
                     Chao1 = chao1, Observed = observed, Shannon = shannon, Simpson = simpson)
write.csv(alpha, "results/stats/alpha_diversity.csv", row.names = FALSE)

## ---- ANOVA per index x health status (cultivar effect), with CLD letters ----
anova_results <- list()
pdf("pdf_output/Fig2B_alpha_diversity.pdf", width = 10, height = 8)
par(mfrow = c(2, 2))
idx_list <- c("Simpson", "Shannon", "Observed", "Chao1")
for (idx in idx_list) {
  for (hs in levels(alpha$health_status)) {
    sub <- alpha[alpha$health_status == hs, ]
    if (length(unique(sub$cultivar)) < 2) next
    fit <- aov(sub[[idx]] ~ cultivar, data = sub)
    a <- summary(fit)
    anova_results[[paste(idx, hs)]] <- data.frame(index = idx, health_status = hs,
                                                   F_value = a[[1]][1, "F value"],
                                                   P_value = a[[1]][1, "Pr(>F)"])
    lsd <- tryCatch(LSD.test(fit, "cultivar", p.adj = "none"), error = function(e) NULL)
    if (!is.null(lsd)) {
      out <- lsd$groups
      write.csv(out, sprintf("results/stats/CLD_%s_%s.csv", idx, hs))
    }
  }
}
anova_df <- do.call(rbind, anova_results)
write.csv(anova_df, "results/stats/alpha_ANOVA.csv", row.names = FALSE)

## boxplots matching Fig 2B layout: one panel per index, cultivar on x, faceted by health_status
for (idx in idx_list) {
  p <- ggplot(alpha, aes(x = cultivar, y = .data[[idx]], fill = cultivar)) +
    geom_boxplot(outlier.size = 0.8) +
    facet_wrap(~health_status, scales = "free_x") +
    theme_bw() + theme(axis.text.x = element_text(angle = 45, hjust = 1), legend.position = "none") +
    labs(title = idx, x = NULL, y = idx)
  print(p)
}
dev.off()

## ---- Beta diversity: Bray-Curtis + PCoA ----
bray <- vegdist(otu_rare, method = "bray")
pcoa <- pcoa(bray)
pc <- as.data.frame(pcoa$vectors[, 1:2])
colnames(pc) <- c("PCo1", "PCo2")
pc$cultivar <- meta$cultivar
pc$health_status <- meta$health_status
varexp <- round(100 * pcoa$values$Relative_eig[1:2], 1)

pdf("pdf_output/Fig3_PCoA_BrayCurtis.pdf", width = 7, height = 6)
p <- ggplot(pc, aes(PCo1, PCo2, color = cultivar, shape = health_status)) +
  geom_point(size = 3) + theme_bw() +
  labs(x = sprintf("PCo1 [%.1f%%]", varexp[1]), y = sprintf("PCo2 [%.1f%%]", varexp[2]),
       title = "PCoA on Bray-Curtis dissimilarity")
print(p)
dev.off()

## ---- PERMANOVA: health_status * cultivar ----
set.seed(42)
perm <- adonis2(bray ~ health_status * cultivar, data = meta, permutations = 999, by = "terms")
write.csv(as.data.frame(perm), "results/stats/PERMANOVA_healthstatus_cultivar.csv")
print(perm)

cat("DONE: diversity_stats\n")
