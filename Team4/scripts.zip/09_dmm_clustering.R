#!/usr/bin/env Rscript
# Reproduces Fig. 5B/D: Dirichlet-multinomial mixture (DMM) clustering of the
# ASV count table, k = 1..7, with k = 4 reported as in the paper.
suppressPackageStartupMessages({
  library(DirichletMultinomial); library(pheatmap); library(RColorBrewer); library(ggplot2)
})
set.seed(42)

BASE <- "/projects/intro2gds/I2GDS2026/Team4/vinny/Claude_Code"
setwd(BASE)
dir.create("results/stats", showWarnings = FALSE, recursive = TRUE)
dir.create("pdf_output", showWarnings = FALSE)

ft <- read.delim("results/exports/table/feature-table.tsv", skip = 1, row.names = 1, check.names = FALSE)
tax <- read.delim("results/exports/taxonomy/taxonomy.tsv", check.names = FALSE)
otu <- t(as.matrix(ft))          # samples x ASVs (DMM convention)
storage.mode(otu) <- "integer"

## keep ASVs present in at least 2 samples (avoid singleton-only columns destabilizing the fit)
keep <- colSums(otu > 0) >= 2
otu_f <- otu[, keep]
## drop any sample left with zero total count after ASV filtering (dmn() requires rowSums > 0)
zero_samples <- rownames(otu_f)[rowSums(otu_f) == 0]
if (length(zero_samples) > 0) {
  cat("Dropping", length(zero_samples), "sample(s) with zero reads after ASV filtering:",
      paste(zero_samples, collapse = ", "), "\n")
  otu_f <- otu_f[rowSums(otu_f) > 0, ]
}
cat("DMM input:", nrow(otu_f), "samples x", ncol(otu_f), "ASVs (filtered from", nrow(otu), "x", ncol(otu), ")\n")

## ---- Fit k = 1..7, record Laplace approximation for model selection ----
fits <- lapply(1:7, function(k) dmn(otu_f, k, verbose = FALSE))
lp <- sapply(fits, DirichletMultinomial::laplace)
sel <- data.frame(k = 1:7, laplace = lp)
write.csv(sel, "results/stats/DMM_model_selection.csv", row.names = FALSE)
cat("Laplace by k:\n"); print(sel)

## ---- Use k = 4 as reported in the paper ----
best <- fits[[4]]
cl <- apply(mixture(best), 1, which.max)
cluster_df <- data.frame(sample = rownames(otu_f), cluster = cl)
write.csv(cluster_df, "results/stats/DMM_k4_cluster_assignments.csv", row.names = FALSE)

## ---- Top driver OTUs per cluster (fitted theta contributions) ----
get_genus <- function(tx) {
  parts <- strsplit(tx, ";")[[1]]
  g <- grep("^g__", parts, value = TRUE)
  s <- grep("^s__", parts, value = TRUE)
  gname <- if (length(g) == 0 || g == "g__") "Unclassified" else sub("^g__", "", g)
  sname <- if (length(s) == 0 || s == "s__") "" else sub("^s__", "", s)
  if (nchar(sname) > 0) paste(gname, sname) else gname
}
tax$label <- sapply(tax$Taxon, get_genus)
label_map <- setNames(tax$label, tax$`Feature ID`)

fitted_mat <- fitted(best)  # ASVs x k, contribution of each ASV to each community type
colnames(fitted_mat) <- paste0("CommunityType", 1:4)

pdf("pdf_output/Fig5D_DMM_top_drivers.pdf", width = 10, height = 8)
driver_tables <- list()
for (k in 1:4) {
  top10 <- head(fitted_mat[order(-fitted_mat[, k]), k, drop = FALSE], 10)
  d <- data.frame(ASV = rownames(top10), taxon = label_map[rownames(top10)], value = top10[, 1])
  driver_tables[[k]] <- d
  d$ASV <- factor(d$ASV, levels = rev(d$ASV))
  p <- ggplot(d, aes(x = ASV, y = value)) + geom_col(fill = "grey30") + coord_flip() +
    theme_bw() + labs(title = paste("Top 10 drivers: Community type", k), x = NULL, y = "Value") +
    geom_text(aes(label = taxon), hjust = -0.05, size = 2.8)
  print(p)
}
dev.off()
write.csv(do.call(rbind, lapply(1:4, function(k) cbind(community_type = k, driver_tables[[k]]))),
          "results/stats/DMM_k4_top_drivers.csv", row.names = FALSE)

## ---- Heatmap of mixture weights (Fig 5B style) ----
mix <- mixture(best)
colnames(mix) <- paste0("CommunityType", 1:4)
pdf("pdf_output/Fig5B_DMM_mixture_heatmap.pdf", width = 8, height = 10)
pheatmap(mix, cluster_cols = FALSE, main = "DMM mixture weights (k=4)",
         color = colorRampPalette(brewer.pal(9, "Blues"))(100))
dev.off()

cat("DONE: dmm_clustering\n")
