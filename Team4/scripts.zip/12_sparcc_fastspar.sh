#!/bin/bash
set -euo pipefail
BASE=/projects/intro2gds/I2GDS2026/Team4/vinny/Claude_Code
cd "$BASE"
module load Miniconda3
source activate microbiome_tools

NBOOT=100
THREADS=${SLURM_CPUS_PER_TASK:-8}

run_sparcc_for () {
  local dir=$1
  echo "=== fastspar on $dir ==="
  cd "$BASE/$dir"
  rm -rf bootstrap_counts bootstrap_correlation
  mkdir -p bootstrap_counts bootstrap_correlation

  fastspar --otu_table otu_table.tsv --correlation median_correlation.tsv \
    --covariance median_covariance.tsv --threads "$THREADS" --iterations 50 --exclude_iterations 10

  fastspar_bootstrap --otu_table otu_table.tsv --number $NBOOT --prefix bootstrap_counts/boot

  for f in bootstrap_counts/boot_*.tsv; do
    n=$(basename "$f" .tsv)
    fastspar --otu_table "$f" \
      --correlation "bootstrap_correlation/cor_${n}.tsv" \
      --covariance "bootstrap_correlation/cov_${n}.tsv" \
      --threads 1 --iterations 50 --exclude_iterations 10 &
    if [[ $(jobs -r -p | wc -l) -ge $THREADS ]]; then wait -n; fi
  done
  wait

  fastspar_pvalues --otu_table otu_table.tsv --correlation median_correlation.tsv \
    --prefix bootstrap_correlation/cor_boot_ --permutations $NBOOT --outfile pvalues.tsv --pseudo
  cd "$BASE"
  echo "=== done $dir ==="
}

run_sparcc_for results/sparcc/canker
run_sparcc_for results/sparcc/healthy

echo "DONE: sparcc_fastspar"
