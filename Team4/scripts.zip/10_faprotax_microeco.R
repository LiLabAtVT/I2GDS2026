#!/usr/bin/env Rscript
# Reproduces Fig. 6: FAPROTAX functional prediction via the microeco package,
# summarized by cultivar x health-status group.
suppressPackageStartupMessages({
  library(microeco); library(pheatmap); library(RColorBrewer)
})
set.seed(42)

BASE <- "/projects/intro2gds/I2GDS2026/Team4/vinny/Claude_Code"
setwd(BASE)
dir.create("results/stats", showWarnings = FALSE, recursive = TRUE)
dir.create("pdf_output", showWarnings = FALSE)

ft <- read.delim("results/exports/table/feature-table.tsv", skip = 1, row.names = 1, check.names = FALSE)
tax_raw <- read.delim("results/exports/taxonomy/taxonomy.tsv", check.names = FALSE)
meta <- read.delim("metadata/sample-metadata.tsv", check.names = FALSE)
meta <- meta[meta$`sample-id` != "#q2:types", ]
rownames(meta) <- meta$`sample-id`
meta <- meta[colnames(ft), ]
meta$group2 <- paste(meta$cultivar, meta$health_status, sep = "_")

## microeco tax_table: columns Kingdom..Species, rownames = ASV id
ranks <- c("Kingdom","Phylum","Class","Order","Family","Genus","Species")
parse_tax <- function(s) {
  parts <- strsplit(s, ";")[[1]]
  parts <- trimws(parts)
  vals <- sapply(c("d__","p__","c__","o__","f__","g__","s__"), function(pref) {
    hit <- grep(paste0("^", pref), parts, value = TRUE)
    if (length(hit) == 0) return(NA)
    v <- sub(paste0("^", pref), "", hit[1])
    if (nchar(v) == 0) NA else v
  })
  names(vals) <- ranks
  vals
}
tax_mat <- t(sapply(tax_raw$Taxon, parse_tax))
rownames(tax_mat) <- tax_raw$`Feature ID`
tax_df <- as.data.frame(tax_mat, stringsAsFactors = FALSE)
for (r in ranks) tax_df[[r]][is.na(tax_df[[r]])] <- "Unclassified"
common <- intersect(rownames(ft), rownames(tax_df))
otu_table <- ft[common, ]
tax_table <- tax_df[common, ]

sample_table <- meta
dataset <- microtable$new(sample_table = sample_table, otu_table = otu_table, tax_table = tax_table)
dataset$tidy_dataset()

t1 <- trans_func$new(dataset)
t1$cal_spe_func(prok_database = "FAPROTAX")
t1$cal_spe_func_perc(abundance_weighted = TRUE, perc = TRUE)

perc <- t1$res_spe_func_perc  # samples x functions (% of taxa with that function)
write.csv(perc, "results/stats/FAPROTAX_percent_by_sample.csv")

## average by cultivar x health_status group
grp <- meta[rownames(perc), "group2"]
perc_grp <- aggregate(perc, by = list(group = grp), FUN = mean)
rownames(perc_grp) <- perc_grp$group
perc_grp$group <- NULL
write.csv(perc_grp, "results/stats/FAPROTAX_percent_by_group.csv")

## keep functions with any non-zero signal, cap to top 40 most variable for legibility
keep_fun <- names(sort(apply(perc_grp, 2, var), decreasing = TRUE))
keep_fun <- keep_fun[1:min(40, length(keep_fun))]

pdf("pdf_output/Fig6_FAPROTAX_heatmap.pdf", width = 12, height = 10)
pheatmap(t(perc_grp[, keep_fun]), cluster_cols = TRUE, cluster_rows = TRUE,
         color = colorRampPalette(brewer.pal(9, "Reds"))(100),
         main = "FAPROTAX functional groups (% of community) by cultivar x health status")
dev.off()

cat("DONE: faprotax_microeco\n")
