#!/bin/bash
set -euo pipefail
BASE=/projects/intro2gds/I2GDS2026/Team4/vinny/Claude_Code
cd "$BASE"
mkdir -p results/lefse

module load R/4.4.2-gfbf-2024a R-bundle-Bioconductor/3.20-foss-2024a-R-4.4.2
Rscript scripts/14_lefse_r_native.R

echo "DONE: lefse"
