#!/usr/bin/env Rscript
# Prepares canker-only and healthy-only OTU count tables for fastspar (SparCC),
# filtered to ASVs present in >=20% of samples within each subset (keeps the
# network to a tractable, interpretable size, as in the paper's ~160-node canker
# network rather than the full raw ASV set).
BASE <- "/projects/intro2gds/I2GDS2026/Team4/vinny/Claude_Code"
setwd(BASE)
dir.create("results/sparcc/canker", showWarnings = FALSE, recursive = TRUE)
dir.create("results/sparcc/healthy", showWarnings = FALSE, recursive = TRUE)

ft <- read.delim("results/exports/table/feature-table.tsv", skip = 1, row.names = 1, check.names = FALSE)
tax <- read.delim("results/exports/taxonomy/taxonomy.tsv", check.names = FALSE)
meta <- read.delim("metadata/sample-metadata.tsv", check.names = FALSE)
meta <- meta[meta$`sample-id` != "#q2:types", ]
rownames(meta) <- meta$`sample-id`
meta <- meta[colnames(ft), ]

get_label <- function(tx) {
  parts <- strsplit(tx, ";")[[1]]
  g <- grep("^g__", parts, value = TRUE)
  gname <- if (length(g) == 0 || g == "g__") "Unclassified" else sub("^g__", "", g)
  gname
}
tax$label <- sapply(tax$Taxon, get_label)
label_map <- setNames(tax$label, tax$`Feature ID`)

write_subset <- function(samples, outdir, keep) {
  sub <- ft[, samples, drop = FALSE]
  sub_f <- sub[keep, , drop = FALSE]
  cat(outdir, ":", nrow(sub_f), "ASVs kept of", nrow(sub), "(", length(samples), "samples )\n")
  out <- cbind(`#OTU ID` = rownames(sub_f), sub_f)
  write.table(out, file.path(outdir, "otu_table.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
  write.csv(data.frame(ASV = rownames(sub_f), genus = label_map[rownames(sub_f)]),
            file.path(outdir, "asv_genus_map.csv"), row.names = FALSE)
}

canker_samples <- rownames(meta)[meta$health_status == "Canker"]
healthy_samples <- rownames(meta)[meta$health_status == "Healthy"]

## Canker: strict prevalence filter (>=20% of samples) keeps the network to a
## tractable, interpretable size (close to the paper's ~160-node canker network).
canker_sub <- ft[, canker_samples, drop = FALSE]
canker_keep <- (rowSums(canker_sub > 0) / length(canker_samples)) >= 0.20
write_subset(canker_samples, "results/sparcc/canker", canker_keep)

## Healthy: these samples are genuinely very sparse post-filtering (see diversity
## results), so a percentage prevalence filter leaves almost nothing. Use an
## absolute-count rule instead (present in >=2 samples OR total reads >=10)
## to retain a workable (if small) network, documented here as a limitation.
healthy_sub <- ft[, healthy_samples, drop = FALSE]
healthy_keep <- (rowSums(healthy_sub > 0) >= 2) | (rowSums(healthy_sub) >= 10)
write_subset(healthy_samples, "results/sparcc/healthy", healthy_keep)

cat("DONE: prep_sparcc_tables\n")
