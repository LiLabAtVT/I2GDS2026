#!/usr/bin/env python3
"""Build QIIME2 sample metadata + manifest from the ENA run table (PRJNA1348523)."""
import csv, os
base = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
rows = list(csv.DictReader(open(f"{base}/metadata/ena_runinfo.tsv"), delimiter="\t"))
code = {"Aztec Fuji": "Fuji", "Cripps Pink": "CP", "Gala": "Gala", "Granniwinkle": "Nic",
        "Hewe's Crab": "HW", "Unknown cultiovar": "UN"}
with open(f"{base}/metadata/sample-metadata.tsv", "w") as md, \
     open(f"{base}/metadata/manifest.tsv", "w") as mf:
    md.write("sample-id\trun\tcultivar\tcultivar_code\treplicate\thealth_status\tgroup\n")
    md.write("#q2:types\tcategorical\tcategorical\tcategorical\tcategorical\tcategorical\tcategorical\n")
    mf.write("sample-id\tabsolute-filepath\n")
    for r in sorted(rows, key=lambda r: r["sample_alias"]):
        cv, rep, status = r["sample_alias"].replace("_HiFi.fastq", "").split("_")
        cultivar = "Unknown cultivar" if cv.startswith("Unknown") else cv
        sid = f"{code[cv]}{rep}{'C' if status == 'Canker' else 'H'}"
        md.write(f"{sid}\t{r['run_accession']}\t{cultivar}\t{code[cv]}\t{rep}\t{status}\t{cultivar}_{status}\n")
        mf.write(f"{sid}\t{base}/raw_data/{r['run_accession']}.fastq.gz\n")
print("wrote", len(rows), "samples")
