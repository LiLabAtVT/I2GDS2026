#!/usr/bin/env Rscript
# Reproduces Fig. 4: genus-level heatmap of canker microbiomes + Random Forest
# classification of cultivar from canker-sample genus abundances (Mean Decrease Gini).
suppressPackageStartupMessages({
  library(randomForest); library(pheatmap); library(RColorBrewer)
  library(reshape2); library(ggplot2); library(dplyr)
})
set.seed(42)

BASE <- "/projects/intro2gds/I2GDS2026/Team4/vinny/Claude_Code"
setwd(BASE)
dir.create("results/stats", showWarnings = FALSE, recursive = TRUE)
dir.create("pdf_output", showWarnings = FALSE)

ft <- read.delim("results/exports/table/feature-table.tsv", skip = 1, row.names = 1, check.names = FALSE)
tax <- read.delim("results/exports/taxonomy/taxonomy.tsv", check.names = FALSE)
meta <- read.delim("metadata/sample-metadata.tsv", check.names = FALSE)
meta <- meta[meta$`sample-id` != "#q2:types", ]
rownames(meta) <- meta$`sample-id`
meta <- meta[colnames(ft), ]

## ---- genus-level aggregation ----
get_genus <- function(tx) {
  parts <- strsplit(tx, ";")[[1]]
  g <- grep("^g__", parts, value = TRUE)
  if (length(g) == 0 || g == "g__") return("Unclassified")
  sub("^g__", "", g)
}
tax$genus <- sapply(tax$Taxon, get_genus)
genus_map <- setNames(tax$genus, tax$`Feature ID`)

ft$genus <- genus_map[rownames(ft)]
ft$genus[is.na(ft$genus)] <- "Unclassified"
genus_tab <- aggregate(. ~ genus, data = ft, FUN = sum)
rownames(genus_tab) <- genus_tab$genus
genus_tab$genus <- NULL
genus_tab <- as.matrix(genus_tab)

## relative abundance (% per sample)
genus_rel <- sweep(genus_tab, 2, colSums(genus_tab), "/") * 100

## ---- Canker-only subset ----
canker_samples <- rownames(meta)[meta$health_status == "Canker"]
canker_rel <- genus_rel[, canker_samples]
canker_meta <- meta[canker_samples, ]
canker_meta$cultivar <- factor(canker_meta$cultivar)

## ---- Fig 4A: top 20 genera heatmap (row z-score), columns grouped by cultivar ----
top20 <- names(sort(rowMeans(canker_rel), decreasing = TRUE))[1:20]
mat <- canker_rel[top20, ]
ord <- order(canker_meta$cultivar)
mat <- mat[, ord]
ann <- data.frame(cultivar = canker_meta$cultivar[ord])
rownames(ann) <- colnames(mat)

pdf("pdf_output/Fig4A_genus_heatmap_canker.pdf", width = 10, height = 8)
pheatmap(mat, scale = "row", cluster_cols = FALSE, cluster_rows = TRUE,
         annotation_col = ann, color = colorRampPalette(c("blue", "white", "red"))(100),
         main = "Top 20 genera - relative abundance (row z-score) - canker samples")
dev.off()

## ---- Fig 4B: Random Forest classification of cultivar from canker genus abundance ----
orig_genus <- rownames(canker_rel)
safe_genus <- make.names(orig_genus, unique = TRUE)
safe2orig <- setNames(orig_genus, safe_genus)

rf_x <- as.data.frame(t(canker_rel))
colnames(rf_x) <- safe_genus
rf_y <- canker_meta$cultivar
rf <- randomForest(x = rf_x, y = rf_y, ntree = 1000, importance = TRUE)
print(rf)

imp <- importance(rf, type = 2)  # MeanDecreaseGini
imp_df <- data.frame(genus = safe2orig[rownames(imp)], MeanDecreaseGini = imp[, 1])
imp_df <- imp_df[order(-imp_df$MeanDecreaseGini), ]
top8 <- head(imp_df, 8)
write.csv(imp_df, "results/stats/RF_importance_all_genera.csv", row.names = FALSE)
write.csv(top8, "results/stats/RF_top8_drivers.csv", row.names = FALSE)

## mean relative abundance of top8 genera per cultivar (for grouped bar chart)
top8_ab <- melt(as.data.frame(t(canker_rel[top8$genus, ])) %>%
                   mutate(cultivar = canker_meta$cultivar),
                 id.vars = "cultivar", variable.name = "genus", value.name = "rel_abund")
top8_summary <- top8_ab %>% group_by(genus, cultivar) %>%
  summarise(mean_rel = mean(rel_abund), sd_rel = sd(rel_abund), .groups = "drop")
write.csv(top8_summary, "results/stats/RF_top8_abundance_by_cultivar.csv", row.names = FALSE)

pdf("pdf_output/Fig4B_RandomForest_importance.pdf", width = 10, height = 6)
p1 <- ggplot(top8, aes(x = reorder(genus, MeanDecreaseGini), y = MeanDecreaseGini)) +
  geom_col(fill = "grey40") + coord_flip() + theme_bw() +
  labs(x = NULL, y = "Mean Decrease Gini", title = "Top 8 Random Forest drivers (cultivar classification, canker samples)")
print(p1)

p2 <- ggplot(top8_summary, aes(x = genus, y = mean_rel, fill = cultivar)) +
  geom_col(position = position_dodge()) +
  geom_errorbar(aes(ymin = mean_rel, ymax = mean_rel + sd_rel), position = position_dodge(0.9), width = 0.2) +
  theme_bw() + theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  labs(x = NULL, y = "Relative abundance (%)", title = "Relative abundance of top 8 RF-driver genera by cultivar")
print(p2)
dev.off()

cat("DONE: random_forest\n")
